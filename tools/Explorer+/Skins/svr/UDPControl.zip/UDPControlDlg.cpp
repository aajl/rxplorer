
// UDPControlDlg.cpp : implementation file
//

#include "stdafx.h"
#include "UDPControl.h"
#include "UDPControlDlg.h"
#include "afxdialogex.h"

#include <gtl/string/str.h>
#include <gtl/io/app_path.h>
#include <gtl/io/ostrm.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CUDPControlDlg dialog
CUDPControlDlg::CUDPControlDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CUDPControlDlg::IDD, pParent)
	, m_strRemoteIP(_T(""))
	, m_nRemotePort(0)
	, m_nLocalPort(0)
	, m_bSaveLog(FALSE)
	, m_strLog(_T(""))
	, m_strLocalIP(_T(""))
{
	m_start = false;
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

CUDPControlDlg::~CUDPControlDlg()
{
	SaveSetting();
}

void CUDPControlDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_TxtRemoteIP, m_strRemoteIP);
	DDX_Text(pDX, IDC_TxtRemotePort, m_nRemotePort);
	DDX_Text(pDX, IDC_TxtLocalPort, m_nLocalPort);
	DDX_Check(pDX, IDC_ChkSaveLog, m_bSaveLog);
	DDX_Text(pDX, IDC_TxtLog, m_strLog);
	DDX_Text(pDX, IDC_LabLocalIP, m_strLocalIP);
}

BEGIN_MESSAGE_MAP(CUDPControlDlg, CDialogEx)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_ChkSaveLog, &CUDPControlDlg::OnBnClickedChksavelog)
	ON_BN_CLICKED(IDC_BtnStart, &CUDPControlDlg::OnBnClickedBtnstart)
END_MESSAGE_MAP()


// CUDPControlDlg message handlers

BOOL CUDPControlDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	m_xml.load(gtl::io::get_app_path<gtl::tstr>() + _T("config.xml"));

	// TODO: Add extra initialization here
	hostent* pHostent = gethostbyname(NULL);
	if(pHostent == NULL)
	{
		MessageBox(_T("��ȡ����IP����"), _T("����"), MB_OK | MB_ICONINFORMATION);
		return TRUE;
	}

	in_addr addr = {0};
	addr.s_addr = *((unsigned long*)pHostent->h_addr_list[0]);
	gtl::str ip = inet_ntoa(addr);
	m_strLocalIP = gtl::tstr(ip);
	
	m_strRemoteIP = m_xml[_T("config")][_T("remote")](_T("ip"));
	m_nRemotePort = m_xml[_T("config")][_T("remote")](_T("port")).cast<int>();
	m_nLocalPort = m_xml[_T("config")][_T("local")](_T("port")).cast<int>();
	m_bSaveLog = m_xml[_T("config")](_T("save")).cast<bool>();

	UpdateData(FALSE);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CUDPControlDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CUDPControlDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CUDPControlDlg::OnBnClickedChksavelog()
{
	// TODO: Add your control notification handler code here
}

void CUDPControlDlg::OnBnClickedBtnstart()
{
	if(m_start)
	{
		m_start = false;
		m_udp.closesocket();

		GetDlgItem(IDC_TxtLocalPort)->EnableWindow(TRUE);
		GetDlgItem(IDC_TxtRemoteIP)->EnableWindow(TRUE);
		GetDlgItem(IDC_TxtRemotePort)->EnableWindow(TRUE);

		GetDlgItem(IDC_BtnStart)->SetWindowText(_T("����"));
		return;
	}

	UpdateData();
	if(m_nLocalPort <= 1024 || m_nLocalPort > 60000)
	{
		MessageBox(_T("�������ն˿ڵķ�ΧΪ: 1025-60000"), _T("����"), MB_OK | MB_ICONINFORMATION);
		return;
	}

	if(m_nRemotePort <= 1024 || m_nRemotePort > 60000)
	{
		MessageBox(_T("�Զ˽��ն˿ڵķ�ΧΪ: 1025-60000"), _T("����"), MB_OK | MB_ICONINFORMATION);
		return;
	}

	if(m_strRemoteIP.IsEmpty())
	{
		MessageBox(_T("�Զ�IP����Ϊ��"), _T("����"), MB_OK | MB_ICONINFORMATION);
		return;
	}

	std::vector<gtl::tstr> vecIP;
	gtl::tstr((LPCTSTR)m_strRemoteIP).split(vecIP, _T("."));
	if(vecIP.size() != 4)
	{
		MessageBox(_T("�Զ�IP��ʽ����"), _T("����"), MB_OK | MB_ICONINFORMATION);
		return;
	}

	SaveSetting();
	GetDlgItem(IDC_TxtLocalPort)->EnableWindow(FALSE);
	GetDlgItem(IDC_TxtRemoteIP)->EnableWindow(FALSE);
	GetDlgItem(IDC_TxtRemotePort)->EnableWindow(FALSE);

	m_start = true;
	m_udp.closesocket();
	m_udp.create(m_nLocalPort, SOCK_DGRAM);
	GetDlgItem(IDC_BtnStart)->SetWindowText(_T("ֹͣ"));

	m_thread.start([this]() -> unsigned long {

		while(this->m_start)
		{
			char buf[1024] = {0};
			int ret = this->m_udp.recvfrom(buf, sizeof(buf) / sizeof(buf[0]));
			if(ret <= 0)
				continue;

			gtl::tstr ip(this->m_udp.getsockaddr());
			int port = this->m_udp.getsockport();

			CTime time = CTime::GetCurrentTime();

			gtl::tstr log;
			log << (LPCTSTR)time.Format(_T("%Y-%m-%d %H:%M:%S\r\n"));
			log << ip << ":" << port;
			log << "    [" << ret << "�ֽ�����]" << "\r\n";

			m_strLog += log;

			CUDPControlDlg* pThis = this;
			this->m_callback.call(log, [pThis](const gtl::tstr& log) {
				pThis->UpdateData(FALSE);
			});
		}

		gtl::dout << "ֹͣ\n";

		return 0;
	});
}

BOOL CUDPControlDlg::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_RETURN)
		return TRUE;

	return CDialogEx::PreTranslateMessage(pMsg);
}

void CUDPControlDlg::SaveSetting()
{
	m_xml.insert_if_not(true);
	m_xml[_T("config")][_T("remote")](_T("ip")) = m_strRemoteIP;
	m_xml[_T("config")][_T("remote")](_T("port")) = gtl::tstr(m_nRemotePort);
	m_xml[_T("config")][_T("local")](_T("port")) = gtl::tstr(m_nLocalPort);
	m_xml[_T("config")](_T("save")) = gtl::tstr(m_bSaveLog);
	m_xml.insert_if_not(false);

	m_xml.save(gtl::io::get_app_path<gtl::tstr>() + _T("config.xml"), _T("utf-8"));
}
